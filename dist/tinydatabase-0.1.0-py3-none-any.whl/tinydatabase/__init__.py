"""
utilapi.

A Cloud Util api.
"""

__version__ = "0.1.0"
__author__ = 'Kishore'
__credits__ = 'Tealpod'